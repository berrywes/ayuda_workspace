package com.example.berry.helpcustomers.activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.fragments.AddProductFragment;
import com.example.berry.helpcustomers.fragments.HomeFragment;
import com.example.berry.helpcustomers.fragments.InventoryFragment;
import com.example.berry.helpcustomers.fragments.SettingsFragment;
import com.example.berry.helpcustomers.scanner.NoScanResultException;
import com.example.berry.helpcustomers.scanner.ScanResultReceiver;
import com.example.berry.helpcustomers.storage.SharedPrefManager;

public class ProfileActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener, ScanResultReceiver, NavigationView.OnNavigationItemSelectedListener {

    //private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState)    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View headerView = navigationView.getHeaderView(0);
        TextView navUsername = (TextView) headerView.findViewById(R.id.user_name);
        TextView navEmail = (TextView) headerView.findViewById(R.id.user_email);

        navUsername.setText(SharedPrefManager.getInstance(this).getUser().getName());
        navEmail.setText(SharedPrefManager.getInstance(this).getUser().getEmail());

        //BottomNavigationView navigationView = findViewById(R.id.bottom_nav);
        //navigationView.setOnNavigationItemSelectedListener(this);

        displayFragment(new HomeFragment());
    }

    private void displayFragment(Fragment fragment){
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    @Override
    protected void onStart() {
        super.onStart();

        // if user is not logged in return to MainActivity
        if (!SharedPrefManager.getInstance(this).isLoggedIn()) {

            // initialize intent to go to MainActivity
            Intent intent = new Intent(this, MainActivity.class);

            // set flag for MainActivity to be next activity
            // and set flag to clear current activity
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

            // start MainActivity
            startActivity(intent);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        Fragment fragment = null;
        Intent intent;
        switch(menuItem.getItemId()){
            case R.id.home:
                Log.i("navigation", "home");

                fragment = new HomeFragment();
                break;
            case R.id.inventory:
                fragment = new InventoryFragment();
                break;
            case R.id.settings:
                fragment = new SettingsFragment();
                break;
            case R.id.prompt_customers:
                intent = new Intent(this, ConversationActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                break;
            case R.id.idle:
                intent = new Intent(this, ConversationActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                break;
        }
        if(fragment != null){
            displayFragment(fragment);

        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        return false;
    }

    public void onClick(View v) {
        Fragment fragment = null;
        switch(v.getId()){
            case R.id.addProductButton:
                fragment = new AddProductFragment();
                break;
        }
        if(fragment!=null){
            displayFragment(fragment);
        }
    }

    @Override
    public void scanResultData(String codeFormat, String codeContent) {
        Fragment fragment = null;

        fragment = new AddProductFragment();
        displayFragment(fragment);

    }

    @Override
    public void scanResultData(NoScanResultException noScanData) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}

