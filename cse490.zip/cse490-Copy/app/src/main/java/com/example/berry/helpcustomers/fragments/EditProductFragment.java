package com.example.berry.helpcustomers.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.api.RetrofitClient;
import com.example.berry.helpcustomers.models.DefaultResponse;
import com.example.berry.helpcustomers.models.ProductResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditProductFragment extends Fragment implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    private TextView textView;
    private int product_id;
    private EditText titleEditText, currencyEditText, priceEditText, descriptionEditText,
                     brandEditText, modelEditText, colorEditText, sizeEditText, dimensionEditText,
                     weightEditText, publisherEditText, isbnEditText, eanEditText, upcEditText,
                     availabilityEditText, imagepathEditText, locationEditText;
    private Switch availabilitySwitch;
    private TextView availabilityTextView;
    private String availabilityString;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        product_id = getArguments().getInt("ID");
    }

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.editproduct_fragment, container, false);
    }


    @Nullable
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        eanEditText = view.findViewById(R.id.ean);
        titleEditText = view.findViewById(R.id.title);
        upcEditText = view.findViewById(R.id.upc);
        descriptionEditText = view.findViewById(R.id.description);
        brandEditText = view.findViewById(R.id.brand);
        modelEditText = view.findViewById(R.id.model);
        colorEditText = view.findViewById(R.id.color);
        sizeEditText = view.findViewById(R.id.size);
        isbnEditText = view.findViewById(R.id.isbn);
        publisherEditText = view.findViewById(R.id.publisher);
        dimensionEditText = view.findViewById(R.id.dimension);
        weightEditText = view.findViewById(R.id.weight);
        currencyEditText = view.findViewById(R.id.currency);
        imagepathEditText = view.findViewById(R.id.image_path);
        priceEditText = view.findViewById(R.id.price);
        availabilitySwitch = view.findViewById(R.id.inStockSwitch);
        availabilityTextView = view.findViewById(R.id.inStockTextView);

        availabilityString = "In Stock";
        availabilitySwitch.setOnCheckedChangeListener(this);

        view.findViewById(R.id.buttonEditProduct).setOnClickListener(this);
        view.findViewById(R.id.buttonCancelProduct).setOnClickListener(this);


        Call<ProductResponse> call = RetrofitClient.getInstance()
                .getApi().getProduct(product_id);

        call.enqueue(new Callback<ProductResponse>(){
            @Override
            public void onResponse(Call<ProductResponse> call, Response<ProductResponse> response) {
                if (response.code() == 200) {

                    String title = response.body().getProduct().getTitle();
                    String currency = response.body().getProduct().getCurrency();
                    String price = response.body().getProduct().getPrice();
                    String description = response.body().getProduct().getDescription();
                    String brand = response.body().getProduct().getBrand();
                    String model = response.body().getProduct().getModel();
                    String color = response.body().getProduct().getColor();
                    String size = response.body().getProduct().getSize();
                    String dimension = response.body().getProduct().getDimension();
                    String weight = response.body().getProduct().getWeight();
                    String publisher = response.body().getProduct().getPublisher();
                    String isbn = response.body().getProduct().getIsbn();
                    String ean = response.body().getProduct().getEan();
                    String upc = response.body().getProduct().getUpc();
                    String availability = response.body().getProduct().getAvailability();
                    String image_path = response.body().getProduct().getImage_path();
                    String location = response.body().getProduct().getLocation();

                    titleEditText.setText(title);
                    currencyEditText.setText(currency);
                    priceEditText.setText(price);
                    descriptionEditText.setText(description);
                    brandEditText.setText(brand);
                    modelEditText.setText(model);
                    colorEditText .setText(color);
                    sizeEditText.setText(size);
                    dimensionEditText .setText(dimension);
                    weightEditText.setText(weight);
                    publisherEditText .setText(publisher);
                    isbnEditText .setText(isbn);
                    eanEditText.setText(ean);
                    upcEditText.setText(upc);
                    availabilityTextView.setText(availability);
                    imagepathEditText.setText(image_path);
                    locationEditText.setText(location);

                    if (availability == "In Stock"){
                        availabilitySwitch.setChecked(true);
                    } else {
                        availabilitySwitch.setChecked(false);
                    }


                } else if (response.code() == 201){
                    Log.i("GetProducts", "201");

                } else if (response.code() == 401){
                    Log.i("GetProducts", "401");

                }
            }

            @Override
            public void onFailure(Call<ProductResponse> call, Throwable t) {
                Log.i("GetProducts", "failure");

            }
        });
    }

    private void displayFragment(Fragment fragment){
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
    @Override
    public void onClick(View v) {
        Fragment fragment = null;

        switch(v.getId()){
            case R.id.buttonEditProduct:
                editProduct();
                break;
            case R.id.buttonCancelProduct:
                fragment = new InventoryFragment();
                break;
            //case R.id.editProductButton:
            // break;
        }
        if(fragment!=null){
            displayFragment(fragment);
        }
    }

    private void editProduct() {
        String ean = eanEditText.getText().toString().trim();
        String title = titleEditText.getText().toString().trim();
        String upc = upcEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();
        String brand = brandEditText.getText().toString().trim();
        String model = modelEditText.getText().toString().trim();
        String color = colorEditText.getText().toString().trim();
        String size = sizeEditText.getText().toString().trim();
        String isbn = isbnEditText.getText().toString().trim();
        String currency = currencyEditText.getText().toString().trim();
        String dimension = dimensionEditText.getText().toString().trim();
        String weight = weightEditText.getText().toString().trim();
        String publisher = publisherEditText.getText().toString().trim();
        String price = priceEditText.getText().toString().trim();
        String location = "N/A";
        String image_path = imagepathEditText.getText().toString().trim();
        String availability = availabilityString;

        if (title.isEmpty()) {
            titleEditText.setError("Title is required");
            titleEditText.requestFocus();
            return;
        }
        if (price.isEmpty()) {
            priceEditText.setError("Price is required");
            priceEditText.requestFocus();
            return;
        }
        if (availability.isEmpty()) {
            availabilityEditText.setError("Availability is required");
            availabilityEditText.requestFocus();
            return;
        }

        Call<DefaultResponse> call = RetrofitClient.getInstance()
                .getApi().updateProduct(
                        product_id,
                        title,
                        currency,
                        price,
                        description,
                        brand,
                        model,
                        color,
                        size,
                        dimension,
                        weight,
                        publisher,
                        isbn,
                        ean,
                        upc,
                        availability,
                        image_path,
                        location
                );
        call.enqueue(new Callback<DefaultResponse>() {
            @Override
            public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {

                DefaultResponse dr = response.body();

                if (response.code() == 200) {
                    Toast.makeText(getActivity().getApplicationContext(),"Product edit successful.", Toast.LENGTH_LONG).show();
                    Fragment fragment = null;
                    fragment = new InventoryFragment();
                    displayFragment(fragment);

                } else if (response.code() == 401){
                    Toast.makeText(getActivity().getApplicationContext(),"Product could not be added.", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getActivity().getApplicationContext(),"Sorry, there was an error.", Toast.LENGTH_LONG).show();
                }
            }


            @Override
            public void onFailure(Call<DefaultResponse> call, Throwable t) {
                Log.e("EditProductError", t.toString());

            }
        });
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if(isChecked) {
            availabilityTextView.setText("In Stock");  //To change the text near to switch
            availabilityString = "In Stock";
        }
        else {
            availabilityTextView.setText("Out of stock");   //To change the text near to switch
            availabilityString = "Out of Stock";

        }
    }
}
