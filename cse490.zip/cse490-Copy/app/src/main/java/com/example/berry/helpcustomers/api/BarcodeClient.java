package com.example.berry.helpcustomers.api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BarcodeClient {
    // initalize variables - assign BASE_URL to slim framework application location URL
    private static final String UPCITE_URL = "https://api.upcitemdb.com/prod/trial/";

    private static BarcodeClient mInstance;
    private Retrofit retrofit;

    private BarcodeClient(){
        retrofit = new Retrofit.Builder()
                .baseUrl(UPCITE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    public static synchronized BarcodeClient getInstance(){
        if(mInstance == null){
            mInstance = new BarcodeClient();

        }
        return mInstance;
    }

    public Api getApi(){
        return retrofit.create(Api.class);
    }
}

