package com.example.berry.helpcustomers.models.ConversationModels;

public class UserDialog {
    public String text;

    public UserDialog(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
