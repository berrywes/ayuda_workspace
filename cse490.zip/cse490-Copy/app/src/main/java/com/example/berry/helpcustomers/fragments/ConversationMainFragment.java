package com.example.berry.helpcustomers.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.activities.ConversationActivity;
import com.example.berry.helpcustomers.activities.MainActivity;
import com.example.berry.helpcustomers.adapters.ConversationAdapter;
import com.example.berry.helpcustomers.api.RetrofitClient;
import com.example.berry.helpcustomers.interfaces.ConversationClickListener;
import com.example.berry.helpcustomers.models.ConversationModels.AssistantDialog;
import com.example.berry.helpcustomers.models.ConversationModels.AssistantDialogOptions;
import com.example.berry.helpcustomers.models.ConversationModels.UserDialog;
import com.example.berry.helpcustomers.models.DefaultResponse;
import com.example.berry.helpcustomers.models.Product;
import com.example.berry.helpcustomers.models.ProductsResponse;
import com.example.berry.helpcustomers.models.User;
import com.example.berry.helpcustomers.storage.SharedPrefManager;
import com.skyfishjy.library.RippleBackground;
import com.dnkilic.waveform.WaveView;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ConversationMainFragment extends Fragment implements View.OnClickListener {

    private RecyclerView recyclerView;
    private ConversationAdapter adapter;
    private ArrayList<Object> items;
    private List<Product> productList;
    private SpeechRecognizer sr;
    private static final String TAG = "SpeechRecognizer";
    private int user_id;
    public ConversationClickListener listener;
    private TextToSpeech mTTS;

    public ConversationMainFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.conversationmain_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mTTS = new TextToSpeech(getActivity(), new TextToSpeech.OnInitListener(){
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS){
                    int result = mTTS.setLanguage(Locale.ENGLISH);
                    if (result == TextToSpeech.LANG_MISSING_DATA
                            || result == TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("TTS", "Language not supported");
                    }
                } else{
                    Log.e("TTS", "Initialization failed");
                }
            }
        });


        items = new ArrayList<>();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new ConversationAdapter(getActivity(),  items, new ConversationClickListener(){
            @Override
            public void onYesClick(int position) {
                items.add(new AssistantDialog("What are you looking for?"));
                speak("What are you looking for");
                adapter.notifyDataSetChanged();
                recyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);

            }

            @Override
            public void onNoClick(int position) {
                items.add(new AssistantDialog("Okay, have a good day!"));
                speak("Okay, have a good day!");
                adapter.notifyDataSetChanged();
                recyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);
            }
        });

        recyclerView.setAdapter(adapter);

        User user = SharedPrefManager.getInstance(getActivity()).getUser();
        user_id = user.getId();
        view.findViewById(R.id.setting).setOnClickListener(this);
        view.findViewById(R.id.play).setOnClickListener(this);

        view.findViewById(R.id.listen).setOnClickListener(this);

        sr = SpeechRecognizer.createSpeechRecognizer(getActivity());
        sr.setRecognitionListener(new listener());
    }

        @Override
    public void onClick(View v) {
        Intent intent;
            switch (v.getId()) {
                case R.id.listen:
                    listen();
                    break;
                case R.id.setting:
                    intent = new Intent(getActivity(), MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    break;
                case R.id.play:
                    items.add(new AssistantDialogOptions("Hi, can I help you find anything?"));
                    speak("Hi, can I help you find anything?");
                    adapter.notifyDataSetChanged();
                    recordInteraction();
                    break;

            }

    }

    private void recordInteraction() {
        Call<DefaultResponse> call =RetrofitClient.getInstance().getApi().postInteraction(user_id, "GENERAL_INTERACTION");
        call.enqueue(new Callback<DefaultResponse>() {
            @Override
            public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {
                if(response.code() == 201) {
                    Log.i("recordInteraction", "Record success");

                }else if (response.code() == 402){
                    Log.i("recordInteraction", "Record failed");

                } else{
                    Log.i("recordInteraction", "Record failed");
                }
            }
            @Override
            public void onFailure(Call<DefaultResponse> call, Throwable t) {
                Log.i("recordInteraction", "Record failed; no response");
            }
        });

    }

    private void listen() {
        Intent intent;
        //get the recognize intent
        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        //Specify the calling package to identify your application
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getClass().getPackage().getName());
        //Given an hint to the recognizer about what the user is going to say
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        //specify the max number of results
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        //User of SpeechRecognizer to "send" the intent.
        sr.startListening(intent);
    }

    class listener implements RecognitionListener {
        public void onReadyForSpeech(Bundle params)  {
            Log.d(TAG, "onReadyForSpeech");
        }
        public void onBeginningOfSpeech(){
            Log.d(TAG, "onBeginningOfSpeech");
        }
        public void onRmsChanged(float rmsdB){
            Log.d(TAG, "onRmsChanged");
        }
        public void onBufferReceived(byte[] buffer)  {
            Log.d(TAG, "onBufferReceived");
        }
        public void onEndOfSpeech()  {
            Log.d(TAG, "onEndofSpeech");
        }
        public void onError(int error)  {
            Log.d(TAG,  "error " +  error);

            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            items.add(new AssistantDialog("Sorry, I didn't catch that."));
            speak("Sorry, I didn't catch that.");
            adapter.notifyDataSetChanged();
            recyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);

            //logthis("error " + error);
        }
        public void onResults(Bundle results) {

            Log.d(TAG, "onResults " + results);
            // Fill the list view with the strings the recognizer thought it could have heard, there should be 5, based on the call
            ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            //display results.
            if (matches.isEmpty()){
                items.add(new AssistantDialog("Sorry, I didn't catch that."));
                speak("Sorry, I didn't catch that.");
                adapter.notifyDataSetChanged();
                recyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);

            }else {
                logthis(matches.get(0));
            }

            //logthis("results: "+String.valueOf(matches.size()));
            for (int i = 0; i < matches.size(); i++) {
                Log.d(TAG, "result " + matches.get(i));
                //logthis("result " +i+":"+ matches.get(i));
                //logthis( matches.get(i));
            }
        }
        public void onPartialResults(Bundle partialResults)
        {
            Log.d(TAG, "onPartialResults");
        }
        public void onEvent(int eventType, Bundle params)
        {
            Log.d(TAG, "onEvent " + eventType);
        }
    }

    public void logthis (String newinfo) {
        if (newinfo != "") {
            items.add(new UserDialog(newinfo));
            adapter.notifyDataSetChanged();
            recyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);
            String[] words = newinfo.split(" ");
            for (int i = 0; i < words.length; i++){

                if (words[i].toLowerCase().equals("yes")){
                    try {
                        TimeUnit.SECONDS.sleep(1);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    items.add(new AssistantDialog("What are you looking for?"));
                    speak("What are you looking for?");

                    adapter.notifyDataSetChanged();
                    recyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);

                } else if (words[i].toLowerCase().equals("no")){

                    items.add(new AssistantDialog("Okay, have a good day!"));
                    speak("Okay, have a good day!");
                    adapter.notifyDataSetChanged();
                    recyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);

                } else {
                    search(newinfo);
                    Log.i("ProductSearch", newinfo);
                    break;
                }
            }
        }
    }

    private void search(String query){

        Call<ProductsResponse> call =RetrofitClient.getInstance().getApi().searchProducts(user_id, query);
        call.enqueue(new Callback<ProductsResponse>() {
            @Override
            public void onResponse(Call<ProductsResponse> call, Response<ProductsResponse> response) {
                if(response.code() == 200) {
                    speak("Here's what I found");
                    Log.e("ProductSearch", "200 passed");
                    productList = response.body().getProducts();
                    items.add(productList);
                    adapter.notifyDataSetChanged();
                    recyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);
                }else if (response.code() == 201){
                    Log.e("ProductSearch", "201  passed");
                } else{
                    Log.e("ProductSearch", response.body().toString());

                    Log.e("ProductSearch", "200 and 201 not passed");
                }
            }
            @Override
            public void onFailure(Call<ProductsResponse> call, Throwable t) {
                Log.e("ProductSearch", "Response failed");
            }
        });
    }
    private void speak(String text){
        float pitch = (float)1.3;
        float speed = (float)1.5;
        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);
        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onDestroy() {
        if ( mTTS != null){
            mTTS.stop();
            mTTS.shutdown();
        }
        super.onDestroy();
    }
}
