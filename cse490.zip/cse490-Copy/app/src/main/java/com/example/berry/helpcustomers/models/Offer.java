package com.example.berry.helpcustomers.models;

public class Offer {
    private String merchant, domain, title, currency, shipping, condition, availability, link;
    private float list_price, price, updated_t;

    public Offer(String merchant, String domain, String title, String currency, String shipping,
                 String condition, String availability, String link, float list_price, float price,
                 float updated_t) {
        this.merchant = merchant;
        this.domain = domain;
        this.title = title;
        this.currency = currency;
        this.shipping = shipping;
        this.condition = condition;
        this.availability = availability;
        this.link = link;
        this.list_price = list_price;
        this.price = price;
        this.updated_t = updated_t;
    }

    public String getMerchant() {
        return merchant;
    }

    public String getDomain() {
        return domain;
    }

    public String getTitle() {
        return title;
    }

    public String getCurrency() {
        return currency;
    }

    public String getShipping() {
        return shipping;
    }

    public String getCondition() {
        return condition;
    }

    public String getAvailability() {
        return availability;
    }

    public String getLink() {
        return link;
    }

    public float getList_price() {
        return list_price;
    }

    public float getPrice() {
        return price;
    }

    public float getUpdated_t() {
        return updated_t;
    }
}
