package com.example.berry.helpcustomers.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.api.RetrofitClient;
import com.example.berry.helpcustomers.image.DownloadImage;
import com.example.berry.helpcustomers.interfaces.FragmentCommunication;
import com.example.berry.helpcustomers.models.DefaultResponse;
import com.example.berry.helpcustomers.models.Product;
import com.example.berry.helpcustomers.models.User;
import com.example.berry.helpcustomers.storage.SharedPrefManager;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ConversationProductsAdapter extends RecyclerView.Adapter<ConversationProductsAdapter.AssistantProductViewHolder> {

    private List<Product> productList;
    private FragmentCommunication communicator;
    private Context ctx;

    public ConversationProductsAdapter(Context ctx, List<Product> productList, FragmentCommunication communication){
        this.productList = productList;
        this.communicator = communication;
        this.ctx = ctx;
    }

    @NonNull
    @Override
    public AssistantProductViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View recyclerSearch = inflater.inflate(R.layout.recycleview_search, viewGroup, false);
        AssistantProductViewHolder holder = new AssistantProductViewHolder(recyclerSearch, communicator);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull AssistantProductViewHolder viewHolder, int position) {
        Product product = productList.get(position);
        if (product != null){
            viewHolder.getProductTitle().setText(product.getTitle());
            viewHolder.getProductPrice().setText(product.getPrice());
            viewHolder.getProductDescription().setText(product.getDescription());

            new DownloadImage((ImageView) viewHolder.getProductImage())
                    .execute(product.getImage_path());
        }
    }




    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class AssistantProductViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView productTitle, productPrice, productDescription;
        ImageView productImage;
        int user_id;
        public AssistantProductViewHolder(@NonNull View itemView, FragmentCommunication communication) {
            super(itemView);
            User user = SharedPrefManager.getInstance(ctx).getUser();
            user_id = user.getId();

            productImage = itemView.findViewById(R.id.productSearchImage);
            productTitle = itemView.findViewById(R.id.textViewSearchName);
            productPrice = itemView.findViewById(R.id.textViewSearchPrice);
            productDescription = itemView.findViewById(R.id.textViewSearchDescription);
            communicator = communication;
            itemView.findViewById(R.id.moreInfoProductButton).setOnClickListener(this);
            itemView.findViewById(R.id.itemRelativeLayout).setOnClickListener(this);
            itemView.findViewById(R.id.navigateButton).setOnClickListener(this);

        }

        public ImageView getProductImage() {
            return productImage;
        }

        public void setProductImage(ImageView productImage) {
            this.productImage = productImage;
        }

        public TextView getProductTitle() {
            return productTitle;
        }

        public void setProductTitle(TextView productTitle) {
            this.productTitle = productTitle;
        }

        public TextView getProductPrice() {
            return productPrice;
        }

        public void setProductPrice(TextView productPrice) {
            this.productPrice = productPrice;
        }

        public TextView getProductDescription() {
            return productDescription;
        }

        public void setProductDescription(TextView productDescription) {
            this.productDescription = productDescription;
        }

        @Override
        public void onClick(View v) {
            switch(v.getId()){
                case R.id.moreInfoProductButton:
                    communicator.respond(productList.get(getAdapterPosition()).getId());
                    break;
                case R.id.itemRelativeLayout:
                    communicator.respond(productList.get(getAdapterPosition()).getId());
                    break;
                case R.id.navigateButton:
                    recordNavigation();
            }
        }
        private void recordNavigation() {
            Call<DefaultResponse> call =RetrofitClient.getInstance().getApi().postNavigation(user_id, "NAVIGATION", productList.get(getAdapterPosition()).getId());
            call.enqueue(new Callback<DefaultResponse>() {
                @Override
                public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {
                    if(response.code() == 201) {
                        Log.i("recordInteraction", "Record success");

                    }else if (response.code() == 402){
                        Log.i("recordInteraction", "Record failed");

                    } else{
                        Log.i("recordInteraction", "Record failed");
                    }
                }
                @Override
                public void onFailure(Call<DefaultResponse> call, Throwable t) {
                    Log.i("recordInteraction", "Record failed; no response");
                }
            });
        }
    }


}

