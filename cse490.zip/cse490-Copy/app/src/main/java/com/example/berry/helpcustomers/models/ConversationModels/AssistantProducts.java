package com.example.berry.helpcustomers.models.ConversationModels;

import com.example.berry.helpcustomers.models.Product;

import java.util.List;

public class AssistantProducts {
    private List<Product> products;

    public AssistantProducts(List<Product> products) {
        this.products = products;
    }

    public List<Product> getProducts() {
        return products;
    }
}
