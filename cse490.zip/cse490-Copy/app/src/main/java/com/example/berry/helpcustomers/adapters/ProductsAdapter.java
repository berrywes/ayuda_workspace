package com.example.berry.helpcustomers.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.image.DownloadImage;
import com.example.berry.helpcustomers.interfaces.FragmentCommunication;
import com.example.berry.helpcustomers.models.Product;

import java.util.List;

public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.ProductsViewHolder>{

    private Context mCtx;
    private List<Product> productList;
    private FragmentCommunication mCommunicator;


    public ProductsAdapter(Context mCtx, List<Product> productList, FragmentCommunication communication) {

        this.mCtx = mCtx;
        this.productList = productList;
        this.mCommunicator = communication;
    }

    @NonNull
    @Override
    public ProductsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mCtx).inflate(R.layout.recycleview_inventory, parent, false);
        ProductsViewHolder holder = new ProductsViewHolder(view, mCommunicator);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ProductsViewHolder holder, int position) {
        Product product = productList.get(position);

        holder.textViewNameProduct.setText(product.getTitle());
        holder.textViewPrice.setText(product.getPrice());
        holder.textViewStatus.setText(product.getAvailability());

        new DownloadImage((ImageView) holder.imageProduct)
                .execute(product.getImage_path());

    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ProductsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        TextView textViewNameProduct, textViewPrice, textViewStatus;
        Button editProductButton;
        FragmentCommunication mCommunication;
        ImageView imageProduct;

        public ProductsViewHolder(@NonNull View itemView, FragmentCommunication Communicator) {
            super(itemView);

            imageProduct = itemView.findViewById(R.id.imageProduct);

            textViewNameProduct = itemView.findViewById(R.id.textViewNameProduct);
            textViewPrice = itemView.findViewById(R.id.textViewPrice);
            textViewStatus = itemView.findViewById(R.id.textViewStatus);
            mCommunication=Communicator;
            editProductButton = itemView.findViewById(R.id.editProductButton);
            editProductButton.setOnClickListener(this);
        }

        @Override
        public void onClick(View view){
            mCommunication.respond( productList.get(getAdapterPosition()).getId());
        }
    }
}
