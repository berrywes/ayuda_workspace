package com.example.berry.helpcustomers.viewholder;


import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.interfaces.ConversationClickListener;

import java.lang.ref.WeakReference;


public class AssistantOptionsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    private TextView dialog;
    private Button yes, no;
    private WeakReference<ConversationClickListener> listenerRef;

    public AssistantOptionsViewHolder(@NonNull View itemView, ConversationClickListener listener) {
        super(itemView);
        dialog = itemView.findViewById(R.id.text);
        itemView.findViewById(R.id.buttonYes).setOnClickListener(this);
        itemView.findViewById(R.id.buttonNo).setOnClickListener(this);
        listenerRef = new WeakReference<>(listener);

    }

    public TextView getDialog() {
        return dialog;
    }

    public void setDialog(TextView dialog) {
        this.dialog = dialog;
    }

    public Button getYes() {
        return yes;
    }

    public void setYes(Button yes) {
        this.yes = yes;
    }

    public Button getNo() {
        return no;
    }

    public void setNo(Button no) {
        this.no = no;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonYes:
                listenerRef.get().onYesClick( getAdapterPosition());
                break;
            case R.id.buttonNo:
                listenerRef.get().onNoClick( getAdapterPosition());
                break;
        }
    }
}
