package com.example.berry.helpcustomers.models;

public class HourlyResponse {
    boolean error;
    Interactions interactions;
    Searches searches;
    Navigations navigations;
    String message;

    public HourlyResponse(boolean error, Interactions interactions, Searches searches, Navigations navigations, String message) {
        this.error = error;
        this.interactions = interactions;
        this.searches = searches;
        this.navigations = navigations;
        this.message = message;
    }

    public boolean isError() {
        return error;
    }

    public Interactions getInteractions() {
        return interactions;
    }

    public Searches getSearches() {
        return searches;
    }

    public Navigations getNavigations() {
        return navigations;
    }

    public String getMessage() {
        return message;
    }
}
