package com.example.berry.helpcustomers.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.api.BarcodeClient;
import com.example.berry.helpcustomers.api.RetrofitClient;
import com.example.berry.helpcustomers.models.BarcodeItem;
import com.example.berry.helpcustomers.models.BarcodeResponse;
import com.example.berry.helpcustomers.models.DefaultResponse;
import com.example.berry.helpcustomers.models.User;
import com.example.berry.helpcustomers.storage.SharedPrefManager;

import java.net.URL;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;



public class AddScannedProductFragment extends  Fragment implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    private String codeContent, codeFormat;
    private EditText titleEditText, currencyEditText, priceEditText, descriptionEditText,
            brandEditText, modelEditText, colorEditText, sizeEditText, dimensionEditText,
            weightEditText, publisherEditText, isbnEditText, eanEditText, upcEditText,
            availabilityEditText, imagepathEditText, locationEditText;

    private Switch availabilitySwitch;
    private TextView availabilityTextView;
    private String availabilityString;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        codeContent = getArguments().getString("codeContent");
        codeFormat = getArguments().getString("codeFormat");
        Log.i("UPC", codeContent);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.addscannedproduct_fragment, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        eanEditText = view.findViewById(R.id.ean);
        titleEditText = view.findViewById(R.id.title);
        upcEditText = view.findViewById(R.id.upc);
        descriptionEditText = view.findViewById(R.id.description);
        brandEditText = view.findViewById(R.id.brand);
        modelEditText = view.findViewById(R.id.model);
        colorEditText = view.findViewById(R.id.color);
        sizeEditText = view.findViewById(R.id.size);
        isbnEditText = view.findViewById(R.id.isbn);
        publisherEditText = view.findViewById(R.id.publisher);
        dimensionEditText = view.findViewById(R.id.dimension);
        weightEditText = view.findViewById(R.id.weight);
        currencyEditText = view.findViewById(R.id.currency);
        availabilitySwitch = view.findViewById(R.id.inStockSwitch);
        availabilityTextView = view.findViewById(R.id.inStockTextView);
        imagepathEditText = view.findViewById(R.id.image_path);
        priceEditText = view.findViewById(R.id.price);
        availabilityString = "In Stock";

        availabilitySwitch.setOnCheckedChangeListener(this);


        view.findViewById(R.id.buttonAddProduct).setOnClickListener(this);
        view.findViewById(R.id.buttonCancelProduct).setOnClickListener(this);
        view.findViewById(R.id.buttonScan).setOnClickListener(this);

        try {
            Call<BarcodeResponse> call = BarcodeClient.getInstance().getApi()
                    .barcodeSearch(codeContent);

            call.enqueue(new Callback<BarcodeResponse>() {
                @Override
                public void onResponse(Call<BarcodeResponse> call, Response<BarcodeResponse> response) {

                    if (response.code() == 200) {

                        List<BarcodeItem> items = response.body().getItems();


                        try {
                            String title = items.get(0).getTitle();
                            titleEditText.setText(title);
                            Log.i("BarcodeSetText", "Success");

                        } catch (NullPointerException e) {
                            String title = "";
                            titleEditText.setText(title);
                            Log.i("BarcodeSetText", "Failed");
                        }

                        try {
                            String currency = items.get(0).getCurrency();
                            currencyEditText.setText(currency);
                        } catch (NullPointerException e) {
                            String currency = "";
                            currencyEditText.setText(currency);
                        }

                        try {
                            String description = items.get(0).getDescription();
                            descriptionEditText.setText(description);
                        } catch (NullPointerException e) {
                            String description = "";
                            descriptionEditText.setText(description);
                        }

                        try {
                            String brand = items.get(0).getBrand();
                            brandEditText.setText(brand);
                        } catch (NullPointerException e) {
                            String brand = "";
                            brandEditText.setText(brand);
                        }

                        try {
                            String model = items.get(0).getModel();
                            modelEditText.setText(model);
                        } catch (NullPointerException e) {
                            String model = "";
                            modelEditText.setText(model);
                        }

                        try {
                            String color = items.get(0).getColor();
                            colorEditText.setText(color);
                        } catch (NullPointerException e) {
                            String color = "";
                            colorEditText.setText(color);
                        }

                        try {
                            String size = items.get(0).getSize();
                            sizeEditText.setText(size);
                        } catch (NullPointerException e) {
                            String size = "";
                            sizeEditText.setText(size);
                        }

                        try {
                            String dimension = items.get(0).getDimension();
                            dimensionEditText.setText(dimension);
                        } catch (NullPointerException e) {
                            String dimension = "";
                            dimensionEditText.setText(dimension);
                        }

                        try {
                            String weight = items.get(0).getWeight();
                            weightEditText.setText(weight);
                        } catch (NullPointerException e) {
                            String weight = "";
                            weightEditText.setText(weight);
                        }

                        try {
                            String publisher = items.get(0).getPublisher();
                            publisherEditText.setText(publisher);
                        } catch (NullPointerException e) {
                            String publisher = "";
                            publisherEditText.setText(publisher);
                        }

                        try {
                            String isbn = items.get(0).getIsbn();
                            isbnEditText.setText(isbn);
                        } catch (NullPointerException e) {
                            String isbn = "";
                            isbnEditText.setText(isbn);
                        }

                        try {
                            String ean = items.get(0).getEan();
                            eanEditText.setText(ean);
                        } catch (NullPointerException e) {
                            String ean = "";
                            eanEditText.setText(ean);
                        }

                        try {
                            String upc = items.get(0).getUpc();
                            upcEditText.setText(upc);
                        } catch (NullPointerException e) {
                            String upc = "";
                            upcEditText.setText(upc);
                        }

                        try {
                            URL[] images = items.get(0).getImages();
                            URL image_path = images[0];
                            imagepathEditText.setText(image_path.toString());
                        } catch (NullPointerException e) {
                            String image_path = "";
                            imagepathEditText.setText(image_path);
                        } catch (IndexOutOfBoundsException e){
                            String image_path = "";
                            imagepathEditText.setText(image_path);
                        }


                    } else if (response.code() == 404) {
                        Toast.makeText(getActivity().getApplicationContext(), "UPC was not found.",
                                Toast.LENGTH_LONG).show();
                    } else if (response.code() == 429) {
                        Toast.makeText(getActivity().getApplicationContext(), "Barcode server is down.",
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getActivity().getApplicationContext(), "Sorry, an error occured.",
                                Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(Call<BarcodeResponse> call, Throwable t) {
                    Log.e("BarcodeAPI", "Response failed");
                    Log.e("BarcodeAPI", String.valueOf(t));
                }
            });
        }catch (IndexOutOfBoundsException e){
            Toast.makeText(getActivity().getApplicationContext(), "No product info.",
                    Toast.LENGTH_LONG).show();
        }catch (Exception e) {
            Toast.makeText(getActivity().getApplicationContext(), "Sorry, an error occurred.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void addProduct() {
        String ean = eanEditText.getText().toString().trim();
        String title = titleEditText.getText().toString().trim();
        String upc = upcEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();
        String brand = brandEditText.getText().toString().trim();
        String model = modelEditText.getText().toString().trim();
        String color = colorEditText.getText().toString().trim();
        String size = sizeEditText.getText().toString().trim();
        String isbn = isbnEditText.getText().toString().trim();
        String currency = currencyEditText.getText().toString().trim();
        String dimension = dimensionEditText.getText().toString().trim();
        String weight = weightEditText.getText().toString().trim();
        String publisher = publisherEditText.getText().toString().trim();
        String price = priceEditText.getText().toString().trim();
        String image_path = imagepathEditText.getText().toString().trim();
        String availability = availabilityString;

        String location = "N/A";


        if (title.isEmpty()) {
            titleEditText.setError("Title is required");
            titleEditText.requestFocus();
            return;
        }
        if (price.isEmpty()) {
            priceEditText.setError("Price is required");
            priceEditText.requestFocus();
            return;
        }



        User user = SharedPrefManager.getInstance(getActivity()).getUser();
        Log.e("PrefManager", String.valueOf(user.getId()));

        Call<DefaultResponse> call = RetrofitClient.getInstance()
                .getApi().createProduct(
                        user.getId(),
                        title,
                        currency,
                        price,
                        description,
                        brand,
                        model,
                        color,
                        size,
                        dimension,
                        weight,
                        publisher,
                        isbn,
                        ean,
                        upc,
                        availability,
                        image_path,
                        location);

        call.enqueue(new Callback<DefaultResponse>() {
            @Override
            public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {

                DefaultResponse dr = response.body();

                if (response.code() == 201) {
                    Toast.makeText(getActivity().getApplicationContext(),"Product added.", Toast.LENGTH_LONG).show();
                    Fragment fragment = null;
                    fragment = new InventoryFragment();
                    displayFragment(fragment);

                } else if (response.code() == 402){
                    Toast.makeText(getActivity().getApplicationContext(),"Product could not be added.", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getActivity().getApplicationContext(),"Sorry, there was an error.", Toast.LENGTH_LONG).show();

                }

            }


            @Override
            public void onFailure(Call<DefaultResponse> call, Throwable t) {

            }
        });

    }

    private void displayFragment(Fragment fragment){
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }


    @Override
    public void onClick(View v) {
        Fragment fragment = null;

        switch(v.getId()){
            case R.id.buttonAddProduct:
                addProduct();
                break;
            case R.id.buttonCancelProduct:
                fragment = new InventoryFragment();
                break;
        }
        if(fragment!=null){
            displayFragment(fragment);
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if(isChecked) {
            availabilityTextView.setText("In Stock");  //To change the text near to switch
            availabilityString = "In Stock";
        }
        else {
            availabilityTextView.setText("Out of stock");   //To change the text near to switch
            availabilityString = "Out of Stock";

        }
    }
}
