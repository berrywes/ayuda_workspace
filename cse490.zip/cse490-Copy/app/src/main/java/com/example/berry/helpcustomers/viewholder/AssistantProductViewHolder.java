package com.example.berry.helpcustomers.viewholder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.berry.helpcustomers.R;

public class AssistantProductViewHolder extends RecyclerView.ViewHolder{
    TextView productTitle, productPrice, produceDescription;

    public AssistantProductViewHolder(@NonNull View itemView) {
        super(itemView);
        productTitle = itemView.findViewById(R.id.textViewSearchName);
        productPrice = itemView.findViewById(R.id.textViewSearchPrice);
        produceDescription = itemView.findViewById(R.id.textViewSearchDescription);
    }

    public TextView getProductTitle() {
        return productTitle;
    }

    public void setProductTitle(TextView productTitle) {
        this.productTitle = productTitle;
    }

    public TextView getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(TextView productPrice) {
        this.productPrice = productPrice;
    }

    public TextView getProduceDescription() {
        return produceDescription;
    }

    public void setProduceDescription(TextView produceDescription) {
        this.produceDescription = produceDescription;
    }
}
