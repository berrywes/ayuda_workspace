package com.example.berry.helpcustomers.models;

import java.lang.reflect.Array;
import java.net.URL;
import java.util.List;

public class BarcodeItem {
    private String ean,title,upc,gtin,elid,description,brand,model,color,size,dimension,weight,
            currency,user_data, publisher, isbn;
    private float lowest_recorded_price,highest_recorded_price;
    private URL images[];
    //private Offer offers[];

    public BarcodeItem(String ean, String title, String upc, String gtin, String elid,
                       String description, String brand, String model, String color, String size,
                       String dimension, String weight, //String currency,
                       String user_data,
                       String publisher, String isbn,
                       float lowest_recorded_price,
                       float highest_recorded_price,
                       URL images[]
                       //Offer offers[]
    ) {
        this.ean = ean;
        this.title = title;
        this.upc = upc;
        this.gtin = gtin;
        this.elid = elid;
        this.description = description;
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.size = size;
        this.dimension = dimension;
        this.weight = weight;
        this.publisher = publisher;
        this.isbn = isbn;
        //this.currency = currency;
        this.user_data = user_data;
        this.lowest_recorded_price = lowest_recorded_price;
        this.highest_recorded_price = highest_recorded_price;
        this.images = images;
        //this.offers = offers;
    }

    public String getEan() {
        return ean;
    }

    public String getTitle() {
        return title;
    }

    public String getUpc() {
        return upc;
    }

    public String getGtin() {
        return gtin;
    }

    public String getElid() {
        return elid;
    }

    public String getDescription() {
        return description;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() { return model; }

    public String getColor() {
        return color;
    }

    public String getSize() {
        return size;
    }

    public String getDimension() {
        return dimension;
    }

    public String getWeight() {
        return weight;
    }

    public String getCurrency() {
        return currency;
    }

    public String getPublisher() { return publisher; }

    public String getIsbn() {
        return isbn;
    }

    public String getUser_data() {
        return user_data;
    }

    public float getLowest_recorded_price() {
        return lowest_recorded_price;
    }

    public float getHighest_recorded_price() { return highest_recorded_price; }

    public URL[] getImages() { return images; }

    //public Offer[] getOffers() {return offers;}
}
