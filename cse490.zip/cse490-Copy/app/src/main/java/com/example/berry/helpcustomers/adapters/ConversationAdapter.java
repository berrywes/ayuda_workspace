package com.example.berry.helpcustomers.adapters;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.activities.ConversationActivity;
import com.example.berry.helpcustomers.fragments.EditProductFragment;
import com.example.berry.helpcustomers.fragments.ProductInfoFragment;
import com.example.berry.helpcustomers.interfaces.ConversationClickListener;
import com.example.berry.helpcustomers.interfaces.FragmentCommunication;
import com.example.berry.helpcustomers.models.ConversationModels.AssistantDialog;
import com.example.berry.helpcustomers.models.ConversationModels.AssistantDialogOptions;
import com.example.berry.helpcustomers.models.ConversationModels.UserDialog;
import com.example.berry.helpcustomers.models.Product;
import com.example.berry.helpcustomers.viewholder.AssistantDialogViewHolder;
import com.example.berry.helpcustomers.viewholder.AssistantOptionsViewHolder;
import com.example.berry.helpcustomers.viewholder.AssistantProductsListViewHolder;
import com.example.berry.helpcustomers.viewholder.UserDialogViewHolder;

import java.util.List;

import static android.app.PendingIntent.getActivity;
import static android.support.v7.widget.RecyclerView.*;

public class ConversationAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Object> items;
    private Context ctx;

    private final int USER_DIALOG = 0, ASSISTANT_DIALOG = 1, ASSISTANT_OPTIONS = 2,
                      ASSISTANT_PRODUCT = 3;

    private RecyclerView recyclerView;
    private ConversationProductsAdapter adapter;
    private List<Product> productList;
    public ConversationClickListener listener;

    public ConversationAdapter(){ }

    public ConversationAdapter(Context ctx, List<Object> items, ConversationClickListener listener) {
        this.ctx =ctx;
        this.items = items;
        this.listener = listener;
    }



    @Override
    public int getItemCount() {
        return this.items.size();
    }

    @Override
    public int getItemViewType(int position){

        if (items.get(position) instanceof UserDialog) {
            return USER_DIALOG;
        }else if (items.get(position) instanceof AssistantDialog){
            return ASSISTANT_DIALOG;
        } else if (items.get(position) instanceof AssistantDialogOptions){
            return ASSISTANT_OPTIONS;
        }else if (items.get(position) instanceof List){
            return ASSISTANT_PRODUCT;
        }
        return -1;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());

        switch(viewType){
            case USER_DIALOG:
                View userDialog = inflater.inflate(R.layout.viewholder_userdialog,
                                                    viewGroup, false);
                viewHolder = new UserDialogViewHolder(userDialog);
                break;
            case ASSISTANT_DIALOG:
                View assistantDialog = inflater.inflate(R.layout.viewholder_assistantdialog,
                        viewGroup, false);
                viewHolder = new AssistantDialogViewHolder(assistantDialog);
                break;
            case ASSISTANT_OPTIONS:
                View assistantOptions = inflater.inflate(R.layout.viewholder_assistantoptions,
                        viewGroup, false);
                viewHolder = new AssistantOptionsViewHolder(assistantOptions, listener);
                break;
            case ASSISTANT_PRODUCT:
                View assistantProduct = inflater.inflate(R.layout.viewholder_assistantproducts,
                        viewGroup, false);

                viewHolder = new AssistantProductsListViewHolder(assistantProduct);
                break;
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        switch(viewHolder.getItemViewType()){
            case USER_DIALOG:
                UserDialogViewHolder userDialogViewHolder = (UserDialogViewHolder) viewHolder;
                configureUserDialog(userDialogViewHolder, position);
                break;
            case ASSISTANT_DIALOG:
                AssistantDialogViewHolder assistantDialogViewHolder = (AssistantDialogViewHolder) viewHolder;
                configureAssistantDialog(assistantDialogViewHolder,position);
                break;
            case ASSISTANT_OPTIONS:
                AssistantOptionsViewHolder assistantOptionsViewHolder = (AssistantOptionsViewHolder) viewHolder;
                configureAssistantOptions(assistantOptionsViewHolder, position);
                break;
            case ASSISTANT_PRODUCT:
                AssistantProductsListViewHolder assistantProductsViewHolder = (AssistantProductsListViewHolder) viewHolder;
                configureAssistantProducts(assistantProductsViewHolder, position);
                break;
        }
    }


    private void configureUserDialog(UserDialogViewHolder userDialogViewHolder, int position) {
        UserDialog userDialog = (UserDialog) items.get(position);
        if (userDialog != null){
            userDialogViewHolder.getDialog().setText(userDialog.text);
        }
    }

    private void configureAssistantDialog(AssistantDialogViewHolder assistantDialogViewHolder,
                                          int position) {
        AssistantDialog assistantDialog = (AssistantDialog) items.get(position);
        if (assistantDialog != null){
            assistantDialogViewHolder.getDialog().setText(assistantDialog.text);
        }
    }

    private void configureAssistantOptions(AssistantOptionsViewHolder assistantOptionsViewHolder,
                                           int position) {
        AssistantDialogOptions assistantDialogOptions = (AssistantDialogOptions) items.get(position);
        if (assistantDialogOptions != null){
            assistantOptionsViewHolder.getDialog().setText(assistantDialogOptions.text);
        }
    }

    private void configureAssistantProducts(AssistantProductsListViewHolder assistantProductsViewHolder,
                                            int position) {
        List<Product> productList = (List<Product>) items.get(position);
        if (productList != null){
            recyclerView = assistantProductsViewHolder.getRecyclerView();

            LinearLayoutManager layoutManager
                    = new LinearLayoutManager(ctx, LinearLayoutManager.HORIZONTAL, false);

            recyclerView.setLayoutManager(layoutManager);

            adapter = new ConversationProductsAdapter(ctx,productList, communication);
            recyclerView.setAdapter(adapter);
        }
    }

    FragmentCommunication communication = new FragmentCommunication() {
        @Override
        public void respond( int product_id) {
            ProductInfoFragment productInfoFragment = new ProductInfoFragment();
            Bundle bundle = new Bundle();
            bundle.putInt("ID", product_id);
            productInfoFragment.setArguments(bundle);
            displayFragment(productInfoFragment);
        }
    };

    private void displayFragment(Fragment fragment) {
        ((FragmentActivity)ctx).getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.relativeLayout, fragment)
                .commit();
    }
}
