package com.example.berry.helpcustomers.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.api.RetrofitClient;
import com.example.berry.helpcustomers.models.HourlyInteractions;
import com.example.berry.helpcustomers.models.HourlyResponse;
import com.example.berry.helpcustomers.models.User;
import com.example.berry.helpcustomers.storage.SharedPrefManager;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.ViewPortHandler;

import org.apache.commons.lang3.ArrayUtils;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment implements View.OnClickListener {

    private TextView interactionsData, searchesData, navigationsData;
    private Long currentTime, currentTimeManip, newTime;
    private Float current_to_one, one_to_two, two_to_three, three_to_four, four_to_five, five_to_six,
            six_to_seven, seven_to_eight, eight_to_nine, nine_to_ten, ten_to_eleven,
            eleven_to_twelve, twelve_to_thirteen, thirteen_to_fourteen, fourteen_to_fifteen,
            fifteen_to_sixteen, sixteen_to_seventeen, seventeen_to_eighteen, eighteen_to_nineteen,
            nineteen_to_twenty, twenty_to_twentyone, twentyone_to_twentytwo,
            twentytwo_to_twentythree, twentythree_to_twentyfour, interactions_total, searches_total,
            navigations_total;
    private BarChart interactionsBarChart, searchesBarChart, navigationsBarChart;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_fragment, container, false);
        currentTime = System.currentTimeMillis()/1000;
        currentTimeManip = System.currentTimeMillis()/1000;

        User user = SharedPrefManager.getInstance(getActivity()).getUser();

        interactionsData = view.findViewById(R.id.interactionsData);
        searchesData = view.findViewById(R.id.searchesData);
        navigationsData = view.findViewById(R.id.navigationsData);

        interactionsBarChart = view.findViewById(R.id.interactionsBarChart);
        interactionsBarChart.setDrawBarShadow(false);
        interactionsBarChart.setDrawValueAboveBar(true);
        interactionsBarChart.setDrawMarkers(false);
        interactionsBarChart.setMaxVisibleValueCount(50);
        interactionsBarChart.setPinchZoom(true);
        interactionsBarChart.getLegend().setEnabled(false);
        interactionsBarChart.getDescription().setText("Hourly Interactions");

        searchesBarChart = view.findViewById(R.id.searchesBarChart);
        searchesBarChart.setDrawBarShadow(false);
        searchesBarChart.setDrawValueAboveBar(true);
        searchesBarChart.setDrawMarkers(false);
        searchesBarChart.setMaxVisibleValueCount(50);
        searchesBarChart.setPinchZoom(true);
        searchesBarChart.getLegend().setEnabled(false);
        searchesBarChart.getDescription().setText("Hourly Searches");

        navigationsBarChart = view.findViewById(R.id.navigationsBarChart);
        navigationsBarChart.setDrawBarShadow(false);
        navigationsBarChart.setDrawValueAboveBar(true);
        navigationsBarChart.setDrawMarkers(false);
        navigationsBarChart.setMaxVisibleValueCount(50);
        navigationsBarChart.setPinchZoom(true);
        navigationsBarChart.getLegend().setEnabled(false);
        navigationsBarChart.getDescription().setText("Hourly Navigations");


        Call<HourlyResponse> call = RetrofitClient.getInstance()
                .getApi()
                .getHourlyInteractions(user.getId(), currentTime);
        call.enqueue(new Callback<HourlyResponse>() {
            @Override
            public void onResponse(Call<HourlyResponse> call, Response<HourlyResponse> response) {

                SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:00:00");
                sdf.setTimeZone(java.util.TimeZone.getTimeZone("GMT-4"));

                String hours[] = new String[24];

                for(int i = 0; i < 24; i++){
                    newTime = currentTimeManip - (3600*i);
                    Date date = new java.util.Date(newTime*1000L);
                    String formattedDate = sdf.format(date);
                    hours[i] =(formattedDate);
                    Log.i("Formatted date", formattedDate);
                }
                ArrayUtils.reverse(hours);

                current_to_one = Float.valueOf(response.body().getInteractions().getCurrent_to_one());
                one_to_two = Float.valueOf(response.body().getInteractions().getOne_to_two());
                two_to_three = Float.valueOf(response.body().getInteractions().getTwo_to_three());
                three_to_four = Float.valueOf(response.body().getInteractions().getThree_to_four());
                four_to_five = Float.valueOf(response.body().getInteractions().getFour_to_five());
                five_to_six = Float.valueOf(response.body().getInteractions().getFive_to_six());
                six_to_seven = Float.valueOf(response.body().getInteractions().getSix_to_seven());
                seven_to_eight = Float.valueOf(response.body().getInteractions().getSeven_to_eight());
                eight_to_nine = Float.valueOf(response.body().getInteractions().getEight_to_nine());
                nine_to_ten = Float.valueOf(response.body().getInteractions().getNine_to_ten());
                ten_to_eleven = Float.valueOf(response.body().getInteractions().getTen_to_eleven());
                eleven_to_twelve = Float.valueOf(response.body().getInteractions().getEleven_to_twelve());
                twelve_to_thirteen = Float.valueOf(response.body().getInteractions().getTwelve_to_thirteen());
                thirteen_to_fourteen = Float.valueOf(response.body().getInteractions().getThirteen_to_fourteen());
                fourteen_to_fifteen = Float.valueOf(response.body().getInteractions().getFourteen_to_fifteen());
                fifteen_to_sixteen = Float.valueOf(response.body().getInteractions().getFifteen_to_sixteen());
                sixteen_to_seventeen = Float.valueOf(response.body().getInteractions().getSixteen_to_seventeen());
                seventeen_to_eighteen = Float.valueOf(response.body().getInteractions().getSeventeen_to_eighteen());
                eighteen_to_nineteen = Float.valueOf(response.body().getInteractions().getEighteen_to_nineteen());
                nineteen_to_twenty = Float.valueOf(response.body().getInteractions().getNineteen_to_twenty());
                twenty_to_twentyone = Float.valueOf(response.body().getInteractions().getTwenty_to_twentyone());
                twentyone_to_twentytwo = Float.valueOf(response.body().getInteractions().getTwentyone_to_twentytwo());
                twentytwo_to_twentythree = Float.valueOf(response.body().getInteractions().getTwentytwo_to_twentythree());
                twentythree_to_twentyfour = Float.valueOf(response.body().getInteractions().getTwentythree_to_twentyfour());

                interactions_total = current_to_one + one_to_two + two_to_three + three_to_four +
                        four_to_five+ five_to_six+ six_to_seven+ seven_to_eight+ eight_to_nine+
                        nine_to_ten+ ten_to_eleven+ eleven_to_twelve+ twelve_to_thirteen+
                        thirteen_to_fourteen+ fourteen_to_fifteen+ fifteen_to_sixteen+
                        sixteen_to_seventeen + seventeen_to_eighteen + eighteen_to_nineteen+
                        nineteen_to_twenty+ twenty_to_twentyone+ twentyone_to_twentytwo+
                        twentytwo_to_twentythree+ twentythree_to_twentyfour;

                interactionsData.setText(interactions_total.toString());

                ArrayList<BarEntry> interactionsBarEntries = new ArrayList<>();

                interactionsBarEntries.add(new BarEntry(23, current_to_one));
                interactionsBarEntries.add(new BarEntry(22, one_to_two));
                interactionsBarEntries.add(new BarEntry(21, two_to_three));
                interactionsBarEntries.add(new BarEntry(20, three_to_four));
                interactionsBarEntries.add(new BarEntry(19, four_to_five));
                interactionsBarEntries.add(new BarEntry(18, five_to_six));
                interactionsBarEntries.add(new BarEntry(17, six_to_seven));
                interactionsBarEntries.add(new BarEntry(16, seven_to_eight));
                interactionsBarEntries.add(new BarEntry(15, eight_to_nine));
                interactionsBarEntries.add(new BarEntry(14, nine_to_ten));
                interactionsBarEntries.add(new BarEntry(13, ten_to_eleven));
                interactionsBarEntries.add(new BarEntry(12, eleven_to_twelve));
                interactionsBarEntries.add(new BarEntry(11, twelve_to_thirteen));
                interactionsBarEntries.add(new BarEntry(10, thirteen_to_fourteen));
                interactionsBarEntries.add(new BarEntry(9, fourteen_to_fifteen));
                interactionsBarEntries.add(new BarEntry(8, fifteen_to_sixteen));
                interactionsBarEntries.add(new BarEntry(7, sixteen_to_seventeen));
                interactionsBarEntries.add(new BarEntry(6, seventeen_to_eighteen));
                interactionsBarEntries.add(new BarEntry(5, eighteen_to_nineteen));
                interactionsBarEntries.add(new BarEntry(4, nineteen_to_twenty));
                interactionsBarEntries.add(new BarEntry(3, twenty_to_twentyone));
                interactionsBarEntries.add(new BarEntry(2, twentyone_to_twentytwo));
                interactionsBarEntries.add(new BarEntry(1, twentytwo_to_twentythree));
                interactionsBarEntries.add(new BarEntry(0, twentythree_to_twentyfour));

                BarDataSet interactionsBarDataSet = new BarDataSet(interactionsBarEntries, "Data set 1");
                interactionsBarDataSet.setColors(ColorTemplate.rgb("#177cdd"));

                BarData data = new BarData(interactionsBarDataSet);
                data.setBarWidth(0.2f);
                data.setValueFormatter(new MyValueFormatter());
                interactionsBarChart.setData(data);


                XAxis xAxis = interactionsBarChart.getXAxis();
                xAxis.setValueFormatter(new MyXAisValueFormatter(hours));
                xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
                xAxis.setGranularity(0.1f);
                YAxis leftAxis = interactionsBarChart.getAxisLeft();
                YAxis rightAxis = interactionsBarChart.getAxisRight();

                leftAxis.setGranularity(1f);
                rightAxis.setGranularity(1f);


                ArrayList<BarEntry> searchesBarEntries = new ArrayList<>();

                current_to_one = Float.valueOf(response.body().getSearches().getCurrent_to_one());
                one_to_two = Float.valueOf(response.body().getSearches().getOne_to_two());
                two_to_three = Float.valueOf(response.body().getSearches().getTwo_to_three());
                three_to_four = Float.valueOf(response.body().getSearches().getThree_to_four());
                four_to_five = Float.valueOf(response.body().getSearches().getFour_to_five());
                five_to_six = Float.valueOf(response.body().getSearches().getFive_to_six());
                six_to_seven = Float.valueOf(response.body().getSearches().getSix_to_seven());
                seven_to_eight = Float.valueOf(response.body().getSearches().getSeven_to_eight());
                eight_to_nine = Float.valueOf(response.body().getSearches().getEight_to_nine());
                nine_to_ten = Float.valueOf(response.body().getSearches().getNine_to_ten());
                ten_to_eleven = Float.valueOf(response.body().getSearches().getTen_to_eleven());
                eleven_to_twelve = Float.valueOf(response.body().getSearches().getEleven_to_twelve());
                twelve_to_thirteen = Float.valueOf(response.body().getSearches().getTwelve_to_thirteen());
                thirteen_to_fourteen = Float.valueOf(response.body().getSearches().getThirteen_to_fourteen());
                fourteen_to_fifteen = Float.valueOf(response.body().getSearches().getFourteen_to_fifteen());
                fifteen_to_sixteen = Float.valueOf(response.body().getSearches().getFifteen_to_sixteen());
                sixteen_to_seventeen = Float.valueOf(response.body().getSearches().getSixteen_to_seventeen());
                seventeen_to_eighteen = Float.valueOf(response.body().getSearches().getSeventeen_to_eighteen());
                eighteen_to_nineteen = Float.valueOf(response.body().getSearches().getEighteen_to_nineteen());
                nineteen_to_twenty = Float.valueOf(response.body().getSearches().getNineteen_to_twenty());
                twenty_to_twentyone = Float.valueOf(response.body().getSearches().getTwenty_to_twentyone());
                twentyone_to_twentytwo = Float.valueOf(response.body().getSearches().getTwentyone_to_twentytwo());
                twentytwo_to_twentythree = Float.valueOf(response.body().getSearches().getTwentytwo_to_twentythree());
                twentythree_to_twentyfour = Float.valueOf(response.body().getSearches().getTwentythree_to_twentyfour());

                searches_total = current_to_one + one_to_two + two_to_three + three_to_four +
                        four_to_five+ five_to_six+ six_to_seven+ seven_to_eight+ eight_to_nine+
                        nine_to_ten+ ten_to_eleven+ eleven_to_twelve+ twelve_to_thirteen+
                        thirteen_to_fourteen+ fourteen_to_fifteen+ fifteen_to_sixteen+
                        sixteen_to_seventeen + seventeen_to_eighteen + eighteen_to_nineteen+
                        nineteen_to_twenty+ twenty_to_twentyone+ twentyone_to_twentytwo+
                        twentytwo_to_twentythree+ twentythree_to_twentyfour;

                searchesData.setText(searches_total.toString());


                searchesBarEntries.add(new BarEntry(23, current_to_one));
                searchesBarEntries.add(new BarEntry(22, one_to_two));
                searchesBarEntries.add(new BarEntry(21, two_to_three));
                searchesBarEntries.add(new BarEntry(20, three_to_four));
                searchesBarEntries.add(new BarEntry(19, four_to_five));
                searchesBarEntries.add(new BarEntry(18, five_to_six));
                searchesBarEntries.add(new BarEntry(17, six_to_seven));
                searchesBarEntries.add(new BarEntry(16, seven_to_eight));
                searchesBarEntries.add(new BarEntry(15, eight_to_nine));
                searchesBarEntries.add(new BarEntry(14, nine_to_ten));
                searchesBarEntries.add(new BarEntry(13, ten_to_eleven));
                searchesBarEntries.add(new BarEntry(12, eleven_to_twelve));
                searchesBarEntries.add(new BarEntry(11, twelve_to_thirteen));
                searchesBarEntries.add(new BarEntry(10, thirteen_to_fourteen));
                searchesBarEntries.add(new BarEntry(9, fourteen_to_fifteen));
                searchesBarEntries.add(new BarEntry(8, fifteen_to_sixteen));
                searchesBarEntries.add(new BarEntry(7, sixteen_to_seventeen));
                searchesBarEntries.add(new BarEntry(6, seventeen_to_eighteen));
                searchesBarEntries.add(new BarEntry(5, eighteen_to_nineteen));
                searchesBarEntries.add(new BarEntry(4, nineteen_to_twenty));
                searchesBarEntries.add(new BarEntry(3, twenty_to_twentyone));
                searchesBarEntries.add(new BarEntry(2, twentyone_to_twentytwo));
                searchesBarEntries.add(new BarEntry(1, twentytwo_to_twentythree));
                searchesBarEntries.add(new BarEntry(0, twentythree_to_twentyfour));

                BarDataSet searchesBarDataSet = new BarDataSet(searchesBarEntries, "Data set 1");
                searchesBarDataSet.setColors(ColorTemplate.rgb("#177cdd"));

                BarData searchesData = new BarData(searchesBarDataSet);
                searchesData.setBarWidth(0.2f);
                searchesData.setValueFormatter(new MyValueFormatter());
                searchesBarChart.setData(searchesData);


                XAxis xAxisSearches = searchesBarChart.getXAxis();
                xAxisSearches.setValueFormatter(new MyXAisValueFormatter(hours));
                xAxisSearches.setPosition(XAxis.XAxisPosition.BOTTOM);
                xAxisSearches.setGranularity(0.1f);
                YAxis leftAxisSearches = searchesBarChart.getAxisLeft();
                YAxis rightAxisSearches = searchesBarChart.getAxisRight();

                leftAxisSearches.setGranularity(1f);
                rightAxisSearches.setGranularity(1f);


                ArrayList<BarEntry> navigationsBarEntries = new ArrayList<>();

                current_to_one = Float.valueOf(response.body().getNavigations().getCurrent_to_one());
                one_to_two = Float.valueOf(response.body().getNavigations().getOne_to_two());
                two_to_three = Float.valueOf(response.body().getNavigations().getTwo_to_three());
                three_to_four = Float.valueOf(response.body().getNavigations().getThree_to_four());
                four_to_five = Float.valueOf(response.body().getNavigations().getFour_to_five());
                five_to_six = Float.valueOf(response.body().getNavigations().getFive_to_six());
                six_to_seven = Float.valueOf(response.body().getNavigations().getSix_to_seven());
                seven_to_eight = Float.valueOf(response.body().getNavigations().getSeven_to_eight());
                eight_to_nine = Float.valueOf(response.body().getNavigations().getEight_to_nine());
                nine_to_ten = Float.valueOf(response.body().getNavigations().getNine_to_ten());
                ten_to_eleven = Float.valueOf(response.body().getNavigations().getTen_to_eleven());
                eleven_to_twelve = Float.valueOf(response.body().getNavigations().getEleven_to_twelve());
                twelve_to_thirteen = Float.valueOf(response.body().getNavigations().getTwelve_to_thirteen());
                thirteen_to_fourteen = Float.valueOf(response.body().getNavigations().getThirteen_to_fourteen());
                fourteen_to_fifteen = Float.valueOf(response.body().getNavigations().getFourteen_to_fifteen());
                fifteen_to_sixteen = Float.valueOf(response.body().getNavigations().getFifteen_to_sixteen());
                sixteen_to_seventeen = Float.valueOf(response.body().getNavigations().getSixteen_to_seventeen());
                seventeen_to_eighteen = Float.valueOf(response.body().getNavigations().getSeventeen_to_eighteen());
                eighteen_to_nineteen = Float.valueOf(response.body().getNavigations().getEighteen_to_nineteen());
                nineteen_to_twenty = Float.valueOf(response.body().getNavigations().getNineteen_to_twenty());
                twenty_to_twentyone = Float.valueOf(response.body().getNavigations().getTwenty_to_twentyone());
                twentyone_to_twentytwo = Float.valueOf(response.body().getNavigations().getTwentyone_to_twentytwo());
                twentytwo_to_twentythree = Float.valueOf(response.body().getNavigations().getTwentytwo_to_twentythree());
                twentythree_to_twentyfour = Float.valueOf(response.body().getNavigations().getTwentythree_to_twentyfour());

                navigations_total = current_to_one + one_to_two + two_to_three + three_to_four +
                        four_to_five+ five_to_six+ six_to_seven+ seven_to_eight+ eight_to_nine+
                        nine_to_ten+ ten_to_eleven+ eleven_to_twelve+ twelve_to_thirteen+
                        thirteen_to_fourteen+ fourteen_to_fifteen+ fifteen_to_sixteen+
                        sixteen_to_seventeen + seventeen_to_eighteen + eighteen_to_nineteen+
                        nineteen_to_twenty+ twenty_to_twentyone+ twentyone_to_twentytwo+
                        twentytwo_to_twentythree+ twentythree_to_twentyfour;

                navigationsData.setText(navigations_total.toString());


                navigationsBarEntries.add(new BarEntry(23, current_to_one));
                navigationsBarEntries.add(new BarEntry(22, one_to_two));
                navigationsBarEntries.add(new BarEntry(21, two_to_three));
                navigationsBarEntries.add(new BarEntry(20, three_to_four));
                navigationsBarEntries.add(new BarEntry(19, four_to_five));
                navigationsBarEntries.add(new BarEntry(18, five_to_six));
                navigationsBarEntries.add(new BarEntry(17, six_to_seven));
                navigationsBarEntries.add(new BarEntry(16, seven_to_eight));
                navigationsBarEntries.add(new BarEntry(15, eight_to_nine));
                navigationsBarEntries.add(new BarEntry(14, nine_to_ten));
                navigationsBarEntries.add(new BarEntry(13, ten_to_eleven));
                navigationsBarEntries.add(new BarEntry(12, eleven_to_twelve));
                navigationsBarEntries.add(new BarEntry(11, twelve_to_thirteen));
                navigationsBarEntries.add(new BarEntry(10, thirteen_to_fourteen));
                navigationsBarEntries.add(new BarEntry(9, fourteen_to_fifteen));
                navigationsBarEntries.add(new BarEntry(8, fifteen_to_sixteen));
                navigationsBarEntries.add(new BarEntry(7, sixteen_to_seventeen));
                navigationsBarEntries.add(new BarEntry(6, seventeen_to_eighteen));
                navigationsBarEntries.add(new BarEntry(5, eighteen_to_nineteen));
                navigationsBarEntries.add(new BarEntry(4, nineteen_to_twenty));
                navigationsBarEntries.add(new BarEntry(3, twenty_to_twentyone));
                navigationsBarEntries.add(new BarEntry(2, twentyone_to_twentytwo));
                navigationsBarEntries.add(new BarEntry(1, twentytwo_to_twentythree));
                navigationsBarEntries.add(new BarEntry(0, twentythree_to_twentyfour));

                BarDataSet navigationsBarDataSet = new BarDataSet(navigationsBarEntries, "Data set 1");
                navigationsBarDataSet.setColors(ColorTemplate.rgb("#177cdd"));

                BarData navigationsData = new BarData(navigationsBarDataSet);
                navigationsData.setBarWidth(0.2f);
                navigationsData.setValueFormatter(new MyValueFormatter());
                navigationsBarChart.setData(navigationsData);


                XAxis xAxisNavigations = navigationsBarChart.getXAxis();
                xAxisNavigations.setValueFormatter(new MyXAisValueFormatter(hours));
                xAxisNavigations.setPosition(XAxis.XAxisPosition.BOTTOM);
                xAxisNavigations.setGranularity(0.1f);
                YAxis leftAxisNavigations = navigationsBarChart.getAxisLeft();
                YAxis rightAxisNavigations = navigationsBarChart.getAxisRight();

                leftAxisNavigations.setGranularity(1f);
                rightAxisNavigations.setGranularity(1f);

            }

            @Override
            public void onFailure(Call<HourlyResponse> call, Throwable t) {
                Toast.makeText(getActivity().getApplicationContext(), "Analytics currently unavailable.", Toast.LENGTH_LONG).show();
                Log.i("Analytics API call", "Failured");
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


    }

    public class MyXAisValueFormatter implements IAxisValueFormatter {

        private String[] mValues;

        public MyXAisValueFormatter(String[] values){
            this.mValues = values;
        }

        @Override
        public String getFormattedValue(float value, AxisBase axis) {
            return mValues[(int) value];
        }
    }

    public class MyValueFormatter implements IValueFormatter {

        private DecimalFormat mFormat;

        public MyValueFormatter() {
            mFormat = new DecimalFormat(""); // use one decimal
        }

        @Override
        public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
            // write your logic here
            return mFormat.format(value); // e.g. append a dollar-sign
        }
    }
    public void onClick(View v) {

        switch(v.getId()){

            /*case R.id.customerModeButton:
                Intent intent = new Intent(getActivity(), ConversationActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                break;*/

        }
    }
}
