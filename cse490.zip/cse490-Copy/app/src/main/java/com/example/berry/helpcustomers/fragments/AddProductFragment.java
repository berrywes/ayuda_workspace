package com.example.berry.helpcustomers.fragments;

import android.Manifest;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.api.RetrofitClient;
import com.example.berry.helpcustomers.models.DefaultResponse;
import com.example.berry.helpcustomers.models.User;
import com.example.berry.helpcustomers.storage.SharedPrefManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;



public class AddProductFragment extends  Fragment implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    private int CAMERA_PERMISSION_CODE = 1;
    private String codeContent, codeFormat;
    private EditText titleEditText, currencyEditText, priceEditText, descriptionEditText,
            brandEditText, modelEditText, colorEditText, sizeEditText, dimensionEditText,
            weightEditText, publisherEditText, isbnEditText, eanEditText, upcEditText,
            imagepathEditText;
    private Switch availabilitySwitch;
    private TextView availabilityTextView;
    private String availabilityString;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.addproduct_fragment, container, false);

        return view;
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        eanEditText = view.findViewById(R.id.ean);
        titleEditText = view.findViewById(R.id.title);
        upcEditText = view.findViewById(R.id.upc);
        descriptionEditText = view.findViewById(R.id.description);
        brandEditText = view.findViewById(R.id.brand);
        modelEditText = view.findViewById(R.id.model);
        colorEditText = view.findViewById(R.id.color);
        sizeEditText = view.findViewById(R.id.size);
        isbnEditText = view.findViewById(R.id.isbn);
        publisherEditText = view.findViewById(R.id.publisher);
        dimensionEditText = view.findViewById(R.id.dimension);
        weightEditText = view.findViewById(R.id.weight);
        currencyEditText = view.findViewById(R.id.currency);
        availabilitySwitch = view.findViewById(R.id.inStockSwitch);
        availabilityTextView = view.findViewById(R.id.inStockTextView);
        imagepathEditText = view.findViewById(R.id.image_path);
        priceEditText = view.findViewById(R.id.price);

        availabilityString = "In Stock";
        String location = "n/a";

        availabilitySwitch.setOnCheckedChangeListener(this);

        view.findViewById(R.id.buttonAddProduct).setOnClickListener(this);
        view.findViewById(R.id.buttonCancelProduct).setOnClickListener(this);
        view.findViewById(R.id.buttonScan).setOnClickListener(this);
    }

    private void addProduct() {

        String ean = eanEditText.getText().toString().trim();
        String title = titleEditText.getText().toString().trim();
        String upc = upcEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();
        String brand = brandEditText.getText().toString().trim();
        String model = modelEditText.getText().toString().trim();
        String color = colorEditText.getText().toString().trim();
        String size = sizeEditText.getText().toString().trim();
        String isbn = isbnEditText.getText().toString().trim();
        String currency = currencyEditText.getText().toString().trim();
        String dimension = dimensionEditText.getText().toString().trim();
        String weight = weightEditText.getText().toString().trim();
        String publisher = publisherEditText.getText().toString().trim();
        String price = priceEditText.getText().toString().trim();
        String image_path = imagepathEditText.getText().toString().trim();
        String location = "N/A";
        String availability  = availabilityString;

        if (title.isEmpty()) {
            titleEditText.setError("Title is required");
            titleEditText.requestFocus();
            return;
        }
        if (price.isEmpty()) {
            priceEditText.setError("Price is required");
            priceEditText.requestFocus();
            return;
        }


        User user = SharedPrefManager.getInstance(getActivity()).getUser();
        Log.e("PrefManager", String.valueOf(user.getId()));

        Call<DefaultResponse> call = RetrofitClient.getInstance()
                .getApi().createProduct(
                        user.getId(),
                        title,
                        currency,
                        price,
                        description,
                        brand,
                        model,
                        color,
                        size,
                        dimension,
                        weight,
                        publisher,
                        isbn,
                        ean,
                        upc,
                        availability,
                        image_path,
                        location
                );

        call.enqueue(new Callback<DefaultResponse>() {
            @Override
            public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {

                DefaultResponse dr = response.body();

                if (response.code() == 201) {
                    Toast.makeText(getActivity().getApplicationContext(),"Product added.", Toast.LENGTH_LONG).show();
                    Fragment fragment = null;
                    fragment = new InventoryFragment();
                    displayFragment(fragment);
                } else if (response.code() == 402){
                    Toast.makeText(getActivity().getApplicationContext(),"Product could not be added.", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getActivity().getApplicationContext(),"Sorry, there was an error.", Toast.LENGTH_LONG).show();
                }
        }


        @Override
        public void onFailure(Call<DefaultResponse> call, Throwable t) {

            }
        });

    }

    private void displayFragment(Fragment fragment){
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    private void checkCameraPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission. CAMERA)){
            new AlertDialog.Builder(getActivity())
                    .setTitle("Camera Permission")
                    .setMessage("Camera permission required for barcode scan.")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(getActivity(),
                                    new String[] {Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
                        }
                    })
                    .setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();
        } else{
            ActivityCompat.requestPermissions(getActivity(), new String[] {Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
        }
    }


    @Override
    public void onClick(View v) {
        Fragment fragment = null;

        switch(v.getId()){
            case R.id.buttonAddProduct:
                addProduct();
                break;
            case R.id.buttonCancelProduct:
                fragment = new InventoryFragment();
                break;
            case R.id.buttonScan:
                checkCameraPermission();
                fragment = new ScanFragment();

                break;
            //case R.id.editProductButton:
            // break;
        }
        if(fragment!=null){
            displayFragment(fragment);
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if(isChecked) {
            availabilityTextView.setText("In Stock");  //To change the text near to switch
            availabilityString = "In Stock";
        }
        else {
            availabilityTextView.setText("Out of stock");   //To change the text near to switch
            availabilityString = "Out of Stock";

        }
    }
}
