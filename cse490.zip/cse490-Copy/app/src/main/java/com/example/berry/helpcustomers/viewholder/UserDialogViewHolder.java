package com.example.berry.helpcustomers.viewholder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.berry.helpcustomers.R;

public class UserDialogViewHolder extends RecyclerView.ViewHolder{
    private TextView dialog;

    public UserDialogViewHolder(@NonNull View itemView) {
        super(itemView);
        dialog = itemView.findViewById(R.id.text);
    }

    public TextView getDialog() {
        return dialog;
    }

    public void setDialog(TextView dialog) {
        this.dialog = dialog;
    }
}
