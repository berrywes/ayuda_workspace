package com.example.berry.helpcustomers.models;

import android.util.Log;

public class Product {

    // initialize variables
    private int id;
    private String title, currency, price, description, brand, model, color, size, dimension,
            weight, publisher, isbn, ean, upc, availability, image_path, location;

    public Product(int id, String title, String currency, String price, String description,
                   String brand, String model, String color, String size, String dimension,
                   String weight, String publisher, String isbn, String ean, String upc,
                   String availability, String image_path, String location) {
        this.id = id;
        this.title = title;
        this.currency = currency;
        this.price = price;
        this.description = description;
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.size = size;
        this.dimension = dimension;
        this.weight = weight;
        this.publisher = publisher;
        this.isbn = isbn;
        this.ean = ean;
        this.upc = upc;
        this.availability = availability;
        this.image_path = image_path;
        this.location = location;
    }

    public int getId() { return id; }

    public String getTitle() {
        return title;
    }

    public String getCurrency() {
        return currency;
    }

    public String getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public String getColor() {
        return color;
    }

    public String getSize() {
        return size;
    }

    public String getDimension() {
        return dimension;
    }

    public String getWeight() {
        return weight;
    }

    public String getPublisher() {
        return publisher;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getEan() {
        return ean;
    }

    public String getUpc() {
        return upc;
    }

    public String getAvailability() {
        return availability;
    }

    public String getImage_path() {
        return image_path;
    }

    public String getLocation() {
        return location;
    }
}
