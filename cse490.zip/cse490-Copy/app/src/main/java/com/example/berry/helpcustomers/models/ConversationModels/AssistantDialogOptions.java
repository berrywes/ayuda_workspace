package com.example.berry.helpcustomers.models.ConversationModels;

import android.widget.Button;

public class AssistantDialogOptions{
    public String text;

    public AssistantDialogOptions(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

}
