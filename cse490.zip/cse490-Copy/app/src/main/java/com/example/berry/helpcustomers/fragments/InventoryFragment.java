package com.example.berry.helpcustomers.fragments;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.adapters.ProductsAdapter;
import com.example.berry.helpcustomers.api.RetrofitClient;
import com.example.berry.helpcustomers.interfaces.FragmentCommunication;
import com.example.berry.helpcustomers.models.Product;
import com.example.berry.helpcustomers.models.ProductsResponse;
import com.example.berry.helpcustomers.models.User;
import com.example.berry.helpcustomers.storage.SharedPrefManager;
import com.willowtreeapps.spruce.Spruce;
import com.willowtreeapps.spruce.animation.DefaultAnimations;
import com.willowtreeapps.spruce.sort.DefaultSort;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;




public class InventoryFragment extends Fragment implements View.OnClickListener  {

    private RecyclerView recyclerView;
    private ProductsAdapter adapter;
    private List<Product> productList;
    private Animator spruceAnimator;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {



        return inflater.inflate(R.layout.inventory_fragment, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.addProductButton).setOnClickListener(this);

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity().getApplicationContext()) {
            @Override
            public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
                super.onLayoutChildren(recycler, state);
                initSpruce();
            }
        };

        User user = SharedPrefManager.getInstance(getActivity()).getUser();



        Call<ProductsResponse> call =RetrofitClient.getInstance().getApi().getProducts(user.getId());

        call.enqueue(new Callback<ProductsResponse>() {
            @Override
            public void onResponse(Call<ProductsResponse> call, Response<ProductsResponse> response) {
                if(response.code() == 200) {
                    productList = response.body().getProducts();
                    adapter = new ProductsAdapter(getActivity(), productList, communication);
                    recyclerView.setAdapter(adapter);
                }else if (response.code() == 201){
                    Log.e("ProductError", "201  passed");
                } else{
                    Log.e("ProductError", "200 and 201 not passed");
                }
            }
            @Override
            public void onFailure(Call<ProductsResponse> call, Throwable t) {
                Log.e("ProductError", String.valueOf(t));
            }
        });

        recyclerView.setLayoutManager(linearLayoutManager);


    }
    private void initSpruce() {
        spruceAnimator = new Spruce.SpruceBuilder(recyclerView)
                .sortWith(new DefaultSort(100))
                .animateWith(DefaultAnimations.shrinkAnimator(recyclerView, 500),
                        ObjectAnimator.ofFloat(recyclerView, "translationX", -recyclerView.getWidth(), 0f).setDuration(800))
                .start();
    }


    @Override
    public void onClick(View v) {
        Fragment fragment = null;
        switch(v.getId()){
            case R.id.addProductButton:
                fragment = new AddProductFragment();
                break;
        }
        if(fragment!=null){
            displayFragment(fragment);
        }
    }

    private void displayFragment(Fragment fragment) {
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    FragmentCommunication communication = new FragmentCommunication() {
        @Override
        public void respond( int product_id) {
            EditProductFragment editProductFragment = new EditProductFragment();
            Bundle bundle = new Bundle();
            bundle.putInt("ID", product_id);
            editProductFragment.setArguments(bundle);
            displayFragment(editProductFragment);
        }
    };
}
