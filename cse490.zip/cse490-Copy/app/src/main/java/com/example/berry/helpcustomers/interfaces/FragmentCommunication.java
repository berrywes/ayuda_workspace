package com.example.berry.helpcustomers.interfaces;

public interface FragmentCommunication {
    void respond(int product_id);
}
