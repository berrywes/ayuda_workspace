package com.example.berry.helpcustomers.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.berry.helpcustomers.R;
import com.example.berry.helpcustomers.api.RetrofitClient;
import com.example.berry.helpcustomers.image.DownloadImage;
import com.example.berry.helpcustomers.models.ProductResponse;

import org.w3c.dom.Text;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.berry.helpcustomers.R.layout.productmoreinfo_fragment;

public class ProductInfoFragment extends Fragment implements View.OnClickListener {

    private int product_id;
    private TextView titleTextView, priceTextView, availabilityTextView, brandTextView,
                     descriptionTextView, dimensionsTextView, weightTextView, sizeTextView,
                     modelTextView, upcTextView, colorTextView,publisherTextView, isbnTextView;
    private ImageView productImageView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        product_id = getArguments().getInt("ID");
        Log.i("ProductID", String.valueOf(product_id));
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.productmoreinfo_fragment, container, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        titleTextView = view.findViewById(R.id.productTitle);
        priceTextView = view.findViewById(R.id.productPrice);
        availabilityTextView = view.findViewById(R.id.productAvailability);
        brandTextView = view.findViewById(R.id.productBrand);
        descriptionTextView = view.findViewById(R.id.productDescription);
        dimensionsTextView = view.findViewById(R.id.productDimensions);
        weightTextView = view.findViewById(R.id.productWeight);
        sizeTextView = view.findViewById(R.id.productSize);
        modelTextView = view.findViewById(R.id.productModel);
        upcTextView = view.findViewById(R.id.productUPC);
        colorTextView = view.findViewById(R.id.productColor);
        publisherTextView = view.findViewById(R.id.productPublisher);
        isbnTextView = view.findViewById(R.id.productISBN);

        productImageView = view.findViewById(R.id.productImage);

        view.findViewById(R.id.backButton).setOnClickListener(this);

        Call<ProductResponse> call = RetrofitClient.getInstance()
                .getApi().getProduct(product_id);

        call.enqueue(new Callback<ProductResponse>(){
            @Override
            public void onResponse(Call<ProductResponse> call, Response<ProductResponse> response) {
                Log.i("GetProducts", response.toString());

                String title = response.body().getProduct().getTitle();
                String price = response.body().getProduct().getPrice();
                String description = response.body().getProduct().getDescription();
                String brand = response.body().getProduct().getBrand();
                String model = response.body().getProduct().getModel();
                String color = response.body().getProduct().getColor();
                String size = response.body().getProduct().getSize();
                String dimension = response.body().getProduct().getDimension();
                String weight = response.body().getProduct().getWeight();
                String publisher = response.body().getProduct().getPublisher();
                String isbn = response.body().getProduct().getIsbn();
                String upc = response.body().getProduct().getUpc();
                String availability = response.body().getProduct().getAvailability();
                String image_path = response.body().getProduct().getImage_path();

                titleTextView.setText(title);
                priceTextView.setText(price);
                descriptionTextView.setText(description);
                brandTextView.setText(brand);
                modelTextView.setText(model);
                colorTextView .setText(color);
                sizeTextView.setText(size);
                dimensionsTextView .setText(dimension);
                weightTextView.setText(weight);
                publisherTextView .setText(publisher);
                isbnTextView .setText(isbn);
                upcTextView.setText(upc);
                availabilityTextView.setText(availability);

                new DownloadImage((ImageView) productImageView)
                        .execute(image_path);
            }
            @Override
            public void onFailure(Call<ProductResponse> call, Throwable t) {
                Log.i("GetProducts", "failure");

            }
        });
    }

    private void displayFragment(Fragment fragment){
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.relativeLayout, fragment)
                .commit();
    }
    @Override
    public void onClick(View v) {
        Fragment fragment = null;

        switch(v.getId()){
            case R.id.backButton:
                fragment = new ConversationMainFragment();
                break;
            //case R.id.editProductButton:
            // break;
        }
        if(fragment!=null){
            displayFragment(fragment);
        }
    }
}
