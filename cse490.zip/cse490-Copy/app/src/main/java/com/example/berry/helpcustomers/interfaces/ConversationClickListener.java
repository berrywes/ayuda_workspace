package com.example.berry.helpcustomers.interfaces;

import android.view.View;

public interface ConversationClickListener {
    void onYesClick( int position);
    void onNoClick( int position);
}
