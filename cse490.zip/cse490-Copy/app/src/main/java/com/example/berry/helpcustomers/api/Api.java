package com.example.berry.helpcustomers.api;

import com.example.berry.helpcustomers.models.BarcodeResponse;
import com.example.berry.helpcustomers.models.DefaultResponse;
import com.example.berry.helpcustomers.models.HourlyInteractions;
import com.example.berry.helpcustomers.models.HourlyResponse;
import com.example.berry.helpcustomers.models.LoginResponse;
import com.example.berry.helpcustomers.models.ProductResponse;
import com.example.berry.helpcustomers.models.ProductsResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface Api {

    @FormUrlEncoded
    @POST("createuser/")
    Call<DefaultResponse> createUser(
            @Field("email") String email,
            @Field("password") String password,
            @Field("name") String name

    );

    @FormUrlEncoded
    @POST("userlogin/")
    Call<LoginResponse> userLogin(
            @Field("email") String email,
            @Field("password") String password
    );

    @FormUrlEncoded
    @POST("post_general_interaction/")
    Call<DefaultResponse> postInteraction(
            @Field("user_id") int user_id,
            @Field("interaction_type") String interaction_type
    );

    @FormUrlEncoded
    @POST("post_navigation/")
    Call<DefaultResponse> postNavigation(
            @Field("user_id") int user_id,
            @Field("interaction_type") String interaction_type,
            @Field("product_id") int product_id
    );

    @FormUrlEncoded
    @PUT("updateuser/{id}/")
    Call<LoginResponse> updateUser(
        @Path("id") int id,
        @Field("email") String email,
        @Field("name") String name

    );

    @FormUrlEncoded
    @PUT("updatepassword/")
    Call<DefaultResponse> updatePassword(
            @Field("currentpassword") String currentpassword,
            @Field("newpassword") String newpassword,
            @Field("email") String email

    );

    @GET("hourlyinteractions/{id}/{currenttime}/")
    Call<HourlyResponse> getHourlyInteractions(
        @Path("id") int id,
        @Path("currenttime") long currenttime);

    @GET("getproducts/{id}/")
    Call<ProductsResponse> getProducts(
            @Path("id") int id);

    @GET("getproduct/{id}/")
    Call<ProductResponse> getProduct(
            @Path("id") int id);


    @FormUrlEncoded
    @POST("createproduct/")
    Call<DefaultResponse> createProduct(
            @Field("user_id") int user_id,
            @Field("title") String title,
            @Field("currency") String currency,
            @Field("price") String price,
            @Field("description") String description,
            @Field("brand") String brand,
            @Field("model") String model,
            @Field("color") String color,
            @Field("size") String size,
            @Field("dimension") String dimension,
            @Field("weight") String weight,
            @Field("publisher") String publisher,
            @Field("isbn") String isbn,
            @Field("ean") String ean,
            @Field("upc") String upc,
            @Field("availability") String availability,
            @Field("image_path") String image_path,
            @Field("location") String location);

    @FormUrlEncoded
    @PUT("updateproduct/{id}/")
    Call<DefaultResponse> updateProduct(
            @Path("id") int id,
            @Field("title") String title,
            @Field("currency") String currency,
            @Field("price") String price,
            @Field("description") String description,
            @Field("brand") String brand,
            @Field("model") String model,
            @Field("color") String color,
            @Field("size") String size,
            @Field("dimension") String dimension,
            @Field("weight") String weight,
            @Field("publisher") String publisher,
            @Field("isbn") String isbn,
            @Field("ean") String ean,
            @Field("upc") String upc,
            @Field("availability") String availability,
            @Field("image_path") String image_path,
            @Field("location") String location);


    @GET("searchproducts/{user_id}/{query}/")
    Call<ProductsResponse> searchProducts(
            @Path("user_id") int user_id,
            @Path("query") String query
    );

    @GET("lookup")
    Call<BarcodeResponse> barcodeSearch(@Query("upc") String upc);

}
