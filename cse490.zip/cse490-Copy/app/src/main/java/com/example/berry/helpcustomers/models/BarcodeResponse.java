package com.example.berry.helpcustomers.models;

import java.util.List;

public class BarcodeResponse {
    private int total, offset;
    private String code;
    private List<BarcodeItem> items;

    public BarcodeResponse(String code, int total, int offset, List<BarcodeItem> items){
        this.code = code;
        this.total = total;
        this.offset = offset;
        this.items = items;
    }

    public int getTotal() {
        return total;
    }

    public int getOffset() {
        return offset;
    }

    public String getCode() {
        return code;
    }

    public List<BarcodeItem> getItems() {
        return items;
    }
}
