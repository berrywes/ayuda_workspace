package com.example.berry.helpcustomers.models.ConversationModels;

public class AssistantDialog {
    public String text;

    public AssistantDialog(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
