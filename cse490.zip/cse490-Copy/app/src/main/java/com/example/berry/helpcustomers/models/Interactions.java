package com.example.berry.helpcustomers.models;

public class Interactions {

    private int current_to_one, one_to_two, two_to_three, three_to_four, four_to_five, five_to_six,
            six_to_seven, seven_to_eight, eight_to_nine, nine_to_ten, ten_to_eleven,
            eleven_to_twelve, twelve_to_thirteen, thirteen_to_fourteen, fourteen_to_fifteen,
            fifteen_to_sixteen, sixteen_to_seventeen, seventeen_to_eighteen, eighteen_to_nineteen,
            nineteen_to_twenty, twenty_to_twentyone, twentyone_to_twentytwo,
            twentytwo_to_twentythree, twentythree_to_twentyfour;

    public Interactions(int current_to_one, int one_to_two, int two_to_three, int three_to_four, int four_to_five, int five_to_six, int six_to_seven, int seven_to_eight, int eight_to_nine, int nine_to_ten, int ten_to_eleven, int eleven_to_twelve, int twelve_to_thirteen, int thirteen_to_fourteen, int fourteen_to_fifteen, int fifteen_to_sixteen, int sixteen_to_seventeen, int seventeen_to_eighteen, int eighteen_to_nineteen, int nineteen_to_twenty, int twenty_to_twentyone, int twentyone_to_twentytwo, int twentytwo_to_twentythree, int twentythree_to_twentyfour) {
        this.current_to_one = current_to_one;
        this.one_to_two = one_to_two;
        this.two_to_three = two_to_three;
        this.three_to_four = three_to_four;
        this.four_to_five = four_to_five;
        this.five_to_six = five_to_six;
        this.six_to_seven = six_to_seven;
        this.seven_to_eight = seven_to_eight;
        this.eight_to_nine = eight_to_nine;
        this.nine_to_ten = nine_to_ten;
        this.ten_to_eleven = ten_to_eleven;
        this.eleven_to_twelve = eleven_to_twelve;
        this.twelve_to_thirteen = twelve_to_thirteen;
        this.thirteen_to_fourteen = thirteen_to_fourteen;
        this.fourteen_to_fifteen = fourteen_to_fifteen;
        this.fifteen_to_sixteen = fifteen_to_sixteen;
        this.sixteen_to_seventeen = sixteen_to_seventeen;
        this.seventeen_to_eighteen = seventeen_to_eighteen;
        this.eighteen_to_nineteen = eighteen_to_nineteen;
        this.nineteen_to_twenty = nineteen_to_twenty;
        this.twenty_to_twentyone = twenty_to_twentyone;
        this.twentyone_to_twentytwo = twentyone_to_twentytwo;
        this.twentytwo_to_twentythree = twentytwo_to_twentythree;
        this.twentythree_to_twentyfour = twentythree_to_twentyfour;
    }

    public int getCurrent_to_one() {
        return current_to_one;
    }

    public int getOne_to_two() {
        return one_to_two;
    }

    public int getTwo_to_three() {
        return two_to_three;
    }

    public int getThree_to_four() {
        return three_to_four;
    }

    public int getFour_to_five() {
        return four_to_five;
    }

    public int getFive_to_six() {
        return five_to_six;
    }

    public int getSix_to_seven() {
        return six_to_seven;
    }

    public int getSeven_to_eight() {
        return seven_to_eight;
    }

    public int getEight_to_nine() {
        return eight_to_nine;
    }

    public int getNine_to_ten() {
        return nine_to_ten;
    }

    public int getTen_to_eleven() {
        return ten_to_eleven;
    }

    public int getEleven_to_twelve() {
        return eleven_to_twelve;
    }

    public int getTwelve_to_thirteen() {
        return twelve_to_thirteen;
    }

    public int getThirteen_to_fourteen() {
        return thirteen_to_fourteen;
    }

    public int getFourteen_to_fifteen() {
        return fourteen_to_fifteen;
    }

    public int getFifteen_to_sixteen() {
        return fifteen_to_sixteen;
    }

    public int getSixteen_to_seventeen() {
        return sixteen_to_seventeen;
    }

    public int getSeventeen_to_eighteen() {
        return seventeen_to_eighteen;
    }

    public int getEighteen_to_nineteen() {
        return eighteen_to_nineteen;
    }

    public int getNineteen_to_twenty() {
        return nineteen_to_twenty;
    }

    public int getTwenty_to_twentyone() {
        return twenty_to_twentyone;
    }

    public int getTwentyone_to_twentytwo() {
        return twentyone_to_twentytwo;
    }

    public int getTwentytwo_to_twentythree() {
        return twentytwo_to_twentythree;
    }

    public int getTwentythree_to_twentyfour() {
        return twentythree_to_twentyfour;
    }
}
